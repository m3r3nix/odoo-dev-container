# -*- coding: utf-8 -*-
from odoo import models, fields, api, _


class ResPartner(models.Model):
    _inherit = 'res.partner'

    branch_id = fields.Many2one(
        'ar.branch',
        string='Assigned Branch',
        domain="[('company_id', '=', company_id)] if company_id else []",
        tracking=True,
        index=True,
        help="Default branch responsible for this customer."
    )

    # Computed AR Metrics (non-editable, calculated dynamically from posted entries)
    ar_total_receivable = fields.Monetary(
        string='Total Outstanding AR',
        compute='_compute_ar_metrics',
        currency_field='ar_currency_id',
        help="Net outstanding receivable balance from all posted, unreconciled accounting lines."
    )
    ar_overdue_balance = fields.Monetary(
        string='Overdue Balance',
        compute='_compute_ar_metrics',
        currency_field='ar_currency_id',
        help="Receivable amount past due date."
    )
    ar_not_due_balance = fields.Monetary(
        string='Not Yet Due',
        compute='_compute_ar_metrics',
        currency_field='ar_currency_id',
        help="Receivable amount within credit term period."
    )
    ar_last_payment_date = fields.Date(
        string='Last Payment Date',
        compute='_compute_ar_metrics',
        help="Date of the most recently received payment."
    )
    ar_last_payment_amount = fields.Monetary(
        string='Last Payment Amount',
        compute='_compute_ar_metrics',
        currency_field='ar_currency_id'
    )
    ar_latest_invoice_date = fields.Date(
        string='Latest Invoice Date',
        compute='_compute_ar_metrics',
        help="Date of the most recent customer invoice."
    )
    ar_currency_id = fields.Many2one(
        'res.currency',
        string='AR Metric Currency',
        compute='_compute_ar_currency_id'
    )

    # Counts
    ar_invoice_count = fields.Integer(
        string='Invoices Count',
        compute='_compute_ar_counts'
    )
    ar_payment_count = fields.Integer(
        string='Payments Count',
        compute='_compute_ar_counts'
    )
    ar_followup_count = fields.Integer(
        string='Follow-ups Count',
        compute='_compute_ar_counts'
    )
    ar_followup_ids = fields.One2many(
        'ar.followup',
        'partner_id',
        string='Collection Follow-ups'
    )

    def _compute_ar_currency_id(self):
        for partner in self:
            partner.ar_currency_id = partner.company_id.currency_id or self.env.company.currency_id

    def _compute_ar_counts(self):
        for partner in self:
            partner.ar_invoice_count = self.env['account.move'].search_count([
                ('partner_id', '=', partner.id),
                ('move_type', 'in', ('out_invoice', 'out_refund')),
                ('state', '=', 'posted'),
            ])
            partner.ar_payment_count = self.env['account.payment'].search_count([
                ('partner_id', '=', partner.id),
                ('partner_type', '=', 'customer'),
                ('state', '=', 'posted'),
            ])
            partner.ar_followup_count = self.env['ar.followup'].search_count([
                ('partner_id', '=', partner.id),
            ])

    def _compute_ar_metrics(self):
        today = fields.Date.context_today(self)
        MoveLine = self.env['account.move.line']
        Move = self.env['account.move']
        Payment = self.env['account.payment']

        for partner in self:
            company = partner.company_id or self.env.company
            currency = company.currency_id

            # Query all posted unreconciled lines for receivable accounts
            domain = [
                ('partner_id', '=', partner.id),
                ('account_id.account_type', '=', 'asset_receivable'),
                ('move_id.state', '=', 'posted'),
                ('reconciled', '=', False),
                ('company_id', '=', company.id),
            ]
            receivable_lines = MoveLine.search(domain)

            total_rec = 0.0
            overdue = 0.0
            not_due = 0.0

            for line in receivable_lines:
                # residual amount in company currency
                residual = line.amount_residual
                total_rec += residual

                due_date = line.date_maturity or line.date
                if due_date and due_date < today:
                    overdue += residual
                else:
                    not_due += residual

            partner.ar_total_receivable = currency.round(total_rec)
            partner.ar_overdue_balance = currency.round(overdue)
            partner.ar_not_due_balance = currency.round(not_due)

            # Latest invoice date
            latest_invoice = Move.search([
                ('partner_id', '=', partner.id),
                ('move_type', '=', 'out_invoice'),
                ('state', '=', 'posted'),
                ('company_id', '=', company.id),
            ], order='invoice_date desc, id desc', limit=1)
            partner.ar_latest_invoice_date = latest_invoice.invoice_date or False

            # Last payment date and amount
            last_payment = Payment.search([
                ('partner_id', '=', partner.id),
                ('partner_type', '=', 'customer'),
                ('state', '=', 'posted'),
                ('company_id', '=', company.id),
            ], order='date desc, id desc', limit=1)
            if last_payment:
                partner.ar_last_payment_date = last_payment.date
                partner.ar_last_payment_amount = last_payment.amount
            else:
                partner.ar_last_payment_date = False
                partner.ar_last_payment_amount = 0.0

    def action_view_ar_invoices(self):
        self.ensure_one()
        return {
            'name': _('Invoices - %s', self.name),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'domain': [
                ('partner_id', '=', self.id),
                ('move_type', 'in', ('out_invoice', 'out_refund')),
                ('state', '=', 'posted'),
            ],
            'context': {
                'default_partner_id': self.id,
                'default_move_type': 'out_invoice',
            }
        }

    def action_view_ar_payments(self):
        self.ensure_one()
        return {
            'name': _('Payments - %s', self.name),
            'type': 'ir.actions.act_window',
            'res_model': 'account.payment',
            'view_mode': 'list,form',
            'domain': [
                ('partner_id', '=', self.id),
                ('partner_type', '=', 'customer'),
                ('state', '=', 'posted'),
            ],
            'context': {
                'default_partner_id': self.id,
                'default_partner_type': 'customer',
            }
        }

    def action_view_ar_followups(self):
        self.ensure_one()
        return {
            'name': _('Follow-ups - %s', self.name),
            'type': 'ir.actions.act_window',
            'res_model': 'ar.followup',
            'view_mode': 'list,form,calendar',
            'domain': [('partner_id', '=', self.id)],
            'context': {'default_partner_id': self.id}
        }

    def action_open_statement_wizard(self):
        self.ensure_one()
        return {
            'name': _('Customer Account Statement'),
            'type': 'ir.actions.act_window',
            'res_model': 'ar.statement.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_partner_id': self.id,
                'default_company_id': self.company_id.id or self.env.company.id,
                'default_branch_id': self.branch_id.id or False,
            }
        }

    def action_open_aging_wizard(self):
        self.ensure_one()
        return {
            'name': _('Customer AR Aging Report'),
            'type': 'ir.actions.act_window',
            'res_model': 'ar.aging.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_partner_ids': [(6, 0, [self.id])],
                'default_company_id': self.company_id.id or self.env.company.id,
                'default_branch_id': self.branch_id.id or False,
            }
        }
