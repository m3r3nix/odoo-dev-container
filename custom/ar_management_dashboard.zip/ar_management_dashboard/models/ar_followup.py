# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class ArFollowup(models.Model):
    _name = 'ar.followup'
    _description = 'Accounts Receivable Collection Follow-up'
    _inherit = ['mail.thread', 'mail.activity.mixin'] if 'mail.thread' in models.Model._inherit_cache else []
    _order = 'priority desc, followup_date asc, id desc'

    name = fields.Char(
        string='Follow-up Reference',
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: _('New')
    )
    partner_id = fields.Many2one(
        'res.partner',
        string='Customer',
        required=True,
        index=True,
        tracking=True,
        help="Customer account associated with this collection effort."
    )
    move_id = fields.Many2one(
        'account.move',
        string='Related Invoice',
        domain="[('move_type', '=', 'out_invoice'), ('partner_id', '=', partner_id), ('state', '=', 'posted')]",
        tracking=True,
        help="Specific invoice that prompted this follow-up, if applicable."
    )
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
        index=True
    )
    branch_id = fields.Many2one(
        'ar.branch',
        string='Branch',
        domain="[('company_id', '=', company_id)]",
        tracking=True,
        index=True,
        help="Branch responsible for this collection."
    )
    user_id = fields.Many2one(
        'res.users',
        string='Assigned Collector',
        default=lambda self: self.env.user,
        tracking=True,
        index=True,
        help="Team member assigned to follow up with the customer."
    )
    created_by_id = fields.Many2one(
        'res.users',
        string='Created By',
        default=lambda self: self.env.user,
        readonly=True
    )
    followup_date = fields.Date(
        string='Follow-up Date',
        required=True,
        default=fields.Date.context_today,
        tracking=True,
        help="Scheduled date for this collection activity."
    )
    next_followup_date = fields.Date(
        string='Next Follow-up Date',
        tracking=True,
        help="Target date for the next follow-up if unresolved."
    )
    priority = fields.Selection(
        [
            ('0', 'Low'),
            ('1', 'Normal'),
            ('2', 'High'),
            ('3', 'Urgent'),
        ],
        string='Priority',
        default='1',
        tracking=True,
        required=True
    )
    status = fields.Selection(
        [
            ('planned', 'Planned'),
            ('in_progress', 'In Progress'),
            ('contacted', 'Contacted'),
            ('promise_to_pay', 'Promise to Pay'),
            ('resolved', 'Resolved'),
            ('cancelled', 'Cancelled'),
        ],
        string='Status',
        default='planned',
        tracking=True,
        required=True,
        index=True
    )
    contact_method = fields.Selection(
        [
            ('phone', 'Phone Call'),
            ('email', 'Email'),
            ('visit', 'In-Person Visit'),
            ('whatsapp', 'WhatsApp / SMS'),
            ('letter', 'Formal Demand Letter'),
        ],
        string='Contact Method',
        default='phone',
        tracking=True,
        required=True
    )
    notes = fields.Text(
        string='Notes & Conversation Summary',
        help="Internal notes regarding the discussion, customer reasons for delay, etc."
    )
    outcome = fields.Text(
        string='Outcome / Action Plan',
        help="Agreed next steps or resolution details."
    )

    # Promise to pay details
    promised_amount = fields.Monetary(
        string='Promised Amount',
        currency_field='currency_id',
        tracking=True
    )
    promised_date = fields.Date(
        string='Promised Payment Date',
        tracking=True
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.company.currency_id,
        required=True
    )

    # Computed fields
    is_overdue = fields.Boolean(
        string='Is Overdue',
        compute='_compute_is_overdue',
        store=True,
        index=True
    )
    customer_phone = fields.Char(related='partner_id.phone', readonly=True)
    customer_email = fields.Char(related='partner_id.email', readonly=True)
    customer_total_due = fields.Monetary(
        related='partner_id.ar_total_receivable',
        string='Customer Total Outstanding',
        readonly=True,
        currency_field='currency_id'
    )

    @api.depends('followup_date', 'status')
    def _compute_is_overdue(self):
        today = fields.Date.context_today(self)
        for record in self:
            if record.status in ('resolved', 'cancelled'):
                record.is_overdue = False
            elif record.followup_date and record.followup_date < today:
                record.is_overdue = True
            else:
                record.is_overdue = False

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        if self.partner_id:
            if self.partner_id.branch_id and not self.branch_id:
                self.branch_id = self.partner_id.branch_id
            if self.partner_id.company_id and not self.company_id:
                self.company_id = self.partner_id.company_id

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('name', _('New')) == _('New'):
                vals['name'] = self.env['ir.sequence'].next_by_code('ar.followup') or _('FU-%05d', self.env['ar.followup'].search_count([]) + 1)
        return super(ArFollowup, self).create(vals_list)

    def action_set_in_progress(self):
        self.write({'status': 'in_progress'})

    def action_set_contacted(self):
        self.write({'status': 'contacted'})

    def action_set_promise_to_pay(self):
        for rec in self:
            if not rec.promised_date:
                raise UserError(_("Please specify the Promised Payment Date before marking as Promise to Pay."))
            rec.status = 'promise_to_pay'

    def action_set_resolved(self):
        self.write({'status': 'resolved'})

    def action_set_cancelled(self):
        self.write({'status': 'cancelled'})

    def action_schedule_next(self):
        self.ensure_one()
        return {
            'name': _('Schedule Next Follow-up'),
            'type': 'ir.actions.act_window',
            'res_model': 'ar.followup',
            'view_mode': 'form',
            'target': 'current',
            'context': {
                'default_partner_id': self.partner_id.id,
                'default_move_id': self.move_id.id,
                'default_branch_id': self.branch_id.id,
                'default_company_id': self.company_id.id,
                'default_user_id': self.user_id.id,
                'default_followup_date': self.next_followup_date or fields.Date.context_today(self),
                'default_priority': self.priority,
            }
        }
