# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class ArBranch(models.Model):
    _name = 'ar.branch'
    _description = 'Accounts Receivable Branch'
    _order = 'name'

    name = fields.Char(
        string='Branch Name',
        required=True,
        tracking=True,
        help="Display name of the branch or regional office."
    )
    code = fields.Char(
        string='Branch Code',
        required=True,
        tracking=True,
        help="Unique identifier or code for this branch."
    )
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company,
        index=True,
        help="Company to which this branch belongs."
    )
    manager_ids = fields.Many2many(
        'res.users',
        'ar_branch_manager_rel',
        'branch_id',
        'user_id',
        string='Branch Managers',
        domain="[('company_ids', 'in', company_id)]",
        help="Users responsible for overseeing receivables and collections at this branch."
    )
    user_ids = fields.Many2many(
        'res.users',
        'ar_branch_user_rel',
        'branch_id',
        'user_id',
        string='Authorized Users',
        domain="[('company_ids', 'in', company_id)]",
        help="Users who have access to this branch's transactions and records."
    )
    active = fields.Boolean(
        string='Active',
        default=True,
        help="Set to false to archive the branch without deleting historical transactions."
    )
    phone = fields.Char(string='Phone')
    email = fields.Char(string='Email')
    address = fields.Text(string='Address')
    notes = fields.Text(string='Notes')

    currency_id = fields.Many2one(
        related='company_id.currency_id',
        string='Currency',
        readonly=True
    )

    # Computed statistics
    invoice_count = fields.Integer(
        string='Invoices Count',
        compute='_compute_branch_metrics'
    )
    total_receivable = fields.Monetary(
        string='Total Outstanding AR',
        compute='_compute_branch_metrics',
        currency_field='currency_id'
    )
    followup_count = fields.Integer(
        string='Follow-ups Count',
        compute='_compute_branch_metrics'
    )

    _sql_constraints = [
        ('code_company_uniq', 'unique(code, company_id)', 'The branch code must be unique per company!')
    ]

    def _compute_branch_metrics(self):
        for branch in self:
            # Posted customer invoices
            invoices = self.env['account.move'].search([
                ('branch_id', '=', branch.id),
                ('move_type', '=', 'out_invoice'),
                ('state', '=', 'posted'),
            ])
            branch.invoice_count = len(invoices)

            # Unreconciled receivable move lines for this branch
            receivable_lines = self.env['account.move.line'].search([
                ('branch_id', '=', branch.id),
                ('move_id.state', '=', 'posted'),
                ('account_id.account_type', '=', 'asset_receivable'),
                ('reconciled', '=', False),
            ])
            branch.total_receivable = sum(receivable_lines.mapped('amount_residual'))

            # Followups
            followups = self.env['ar.followup'].search([
                ('branch_id', '=', branch.id),
                ('status', 'not in', ('resolved', 'cancelled'))
            ])
            branch.followup_count = len(followups)

    def action_view_invoices(self):
        self.ensure_one()
        return {
            'name': _('Invoices - %s', self.name),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'domain': [
                ('branch_id', '=', self.id),
                ('move_type', 'in', ('out_invoice', 'out_refund')),
                ('state', '=', 'posted')
            ],
            'context': {
                'default_branch_id': self.id,
                'default_move_type': 'out_invoice'
            }
        }

    def action_view_followups(self):
        self.ensure_one()
        return {
            'name': _('Collection Follow-ups - %s', self.name),
            'type': 'ir.actions.act_window',
            'res_model': 'ar.followup',
            'view_mode': 'list,form,calendar',
            'domain': [('branch_id', '=', self.id)],
            'context': {'default_branch_id': self.id}
        }


class ResUsers(models.Model):
    _inherit = 'res.users'

    branch_ids = fields.Many2many(
        'ar.branch',
        'ar_branch_user_rel',
        'user_id',
        'branch_id',
        string='Authorized AR Branches',
        help="Branches that this user is explicitly authorized to view and manage."
    )


class AccountMove(models.Model):
    _inherit = 'account.move'

    branch_id = fields.Many2one(
        'ar.branch',
        string='Branch',
        domain="[('company_id', '=', company_id)]",
        tracking=True,
        index=True,
        copy=False,
        help="Branch responsible for this accounting transaction."
    )

    @api.onchange('partner_id')
    def _onchange_partner_set_branch(self):
        if self.partner_id and self.partner_id.branch_id and not self.branch_id:
            self.branch_id = self.partner_id.branch_id


class AccountPayment(models.Model):
    _inherit = 'account.payment'

    branch_id = fields.Many2one(
        'ar.branch',
        string='Branch',
        domain="[('company_id', '=', company_id)]",
        tracking=True,
        index=True,
        copy=False,
        help="Branch associated with this payment transaction."
    )


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    branch_id = fields.Many2one(
        related='move_id.branch_id',
        string='Branch',
        store=True,
        readonly=True,
        index=True,
        help="Branch linked through the parent journal entry."
    )
