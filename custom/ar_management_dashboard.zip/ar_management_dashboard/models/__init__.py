# -*- coding: utf-8 -*-
from . import ar_branch
from . import ar_followup
from . import res_partner
from . import ar_dashboard
