# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import AccessError, ValidationError
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta


class ArDashboard(models.Model):
    _name = 'ar.dashboard'
    _description = 'Accounts Receivable Dashboard Service'

    name = fields.Char(default="AR Dashboard")

    @api.model
    def _validate_user_scope(self, company_id=None, branch_id=None):
        """
        Server-side validation of user permissions and branch authorization.
        Prevents unauthorized access from spoofed frontend parameters.
        """
        user = self.env.user
        allowed_companies = self.env.companies.ids

        # Validate company
        if company_id:
            if company_id not in allowed_companies:
                raise AccessError(_("You are not authorized to access records for this company."))
            comp_id = company_id
        else:
            comp_id = self.env.company.id

        # Validate branch
        is_admin = user.has_group('ar_management_dashboard.group_ar_admin')
        user_branches = user.branch_ids.ids

        if branch_id:
            branch = self.env['ar.branch'].browse(branch_id)
            if not branch.exists() or branch.company_id.id != comp_id:
                raise ValidationError(_("Selected branch does not belong to the active company."))
            if not is_admin and branch_id not in user_branches:
                raise AccessError(_("You do not have access rights to the selected branch."))
            validated_branch_id = branch_id
        else:
            validated_branch_id = False

        return comp_id, validated_branch_id

    @api.model
    def get_user_context_info(self):
        """Returns companies and branches available to current user."""
        user = self.env.user
        is_admin = user.has_group('ar_management_dashboard.group_ar_admin')
        companies = [{'id': c.id, 'name': c.name, 'currency': c.currency_id.symbol} for c in self.env.companies]

        if is_admin:
            branches = self.env['ar.branch'].search_read(
                [('company_id', 'in', self.env.companies.ids), ('active', '=', True)],
                ['id', 'name', 'code', 'company_id']
            )
        else:
            branches = self.env['ar.branch'].search_read(
                [('id', 'in', user.branch_ids.ids), ('active', '=', True)],
                ['id', 'name', 'code', 'company_id']
            )

        return {
            'is_admin': is_admin,
            'current_company_id': self.env.company.id,
            'companies': companies,
            'branches': branches,
            'currency_symbol': self.env.company.currency_id.symbol,
            'currency_position': self.env.company.currency_id.position,
        }

    @api.model
    def get_dashboard_data(self, company_id=None, branch_id=None, date_from=None, date_to=None):
        """
        Main API method called by OWL dashboard component.
        Calculates all KPI cards, aging distribution, monthly collections, top debtors,
        overdue accounts, recent payments, and follow-up activities.
        """
        comp_id, br_id = self._validate_user_scope(company_id, branch_id)
        company = self.env['res.company'].browse(comp_id)
        currency = company.currency_id
        today = fields.Date.context_today(self)

        # Parse date range for period metrics (defaults to start of current month to today)
        if not date_from:
            date_from = today.replace(day=1)
        elif isinstance(date_from, str):
            date_from = fields.Date.to_date(date_from)

        if not date_to:
            date_to = today
        elif isinstance(date_to, str):
            date_to = fields.Date.to_date(date_to)

        # 1. Base domain for open receivables
        base_line_domain = [
            ('company_id', '=', comp_id),
            ('account_id.account_type', '=', 'asset_receivable'),
            ('move_id.state', '=', 'posted'),
            ('reconciled', '=', False),
        ]
        if br_id:
            base_line_domain.append(('branch_id', '=', br_id))

        open_lines = self.env['account.move.line'].search(base_line_domain)

        # KPI Metrics
        total_outstanding = 0.0
        overdue_total = 0.0
        not_due_total = 0.0
        overdue_90_plus = 0.0

        aging_buckets = {
            'not_due': 0.0,
            'days_1_30': 0.0,
            'days_31_60': 0.0,
            'days_61_90': 0.0,
            'days_over_90': 0.0,
        }

        debtors_map = {}
        overdue_map = {}

        for line in open_lines:
            residual = line.amount_residual
            if not residual:
                continue

            total_outstanding += residual
            due_date = line.date_maturity or line.date

            partner = line.partner_id
            p_id = partner.id if partner else 0
            p_name = partner.name if partner else _("Unassigned Customer")

            if p_id not in debtors_map:
                debtors_map[p_id] = {'id': p_id, 'name': p_name, 'total': 0.0, 'overdue': 0.0}
            debtors_map[p_id]['total'] += residual

            if due_date and due_date < today:
                overdue_total += residual
                days_over = (today - due_date).days
                debtors_map[p_id]['overdue'] += residual

                if p_id not in overdue_map:
                    overdue_map[p_id] = {'id': p_id, 'name': p_name, 'overdue': 0.0, 'max_days': 0}
                overdue_map[p_id]['overdue'] += residual
                if days_over > overdue_map[p_id]['max_days']:
                    overdue_map[p_id]['max_days'] = days_over

                if days_over <= 30:
                    aging_buckets['days_1_30'] += residual
                elif days_over <= 60:
                    aging_buckets['days_31_60'] += residual
                elif days_over <= 90:
                    aging_buckets['days_61_90'] += residual
                else:
                    aging_buckets['days_over_90'] += residual
                    overdue_90_plus += residual
            else:
                not_due_total += residual
                aging_buckets['not_due'] += residual

        # Count distinct customers
        total_customers = len([d for d in debtors_map.values() if d['total'] > 0])
        overdue_customers = len([d for d in debtors_map.values() if d['overdue'] > 0])

        # 2. Collections during period
        # Cash/bank collection credits against asset_receivable
        collection_domain = [
            ('company_id', '=', comp_id),
            ('account_id.account_type', '=', 'asset_receivable'),
            ('move_id.state', '=', 'posted'),
            ('date', '>=', date_from),
            ('date', '<=', date_to),
            ('credit', '>', 0),
            ('move_id.move_type', 'in', ('entry', False)),
        ]
        if br_id:
            collection_domain.append(('branch_id', '=', br_id))

        collection_lines = self.env['account.move.line'].search(collection_domain)
        collections_period = sum(collection_lines.mapped('credit'))

        # Invoiced during period (for collection rate denominator)
        invoice_domain = [
            ('company_id', '=', comp_id),
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('invoice_date', '>=', date_from),
            ('invoice_date', '<=', date_to),
        ]
        if br_id:
            invoice_domain.append(('branch_id', '=', br_id))
        invoices_period = sum(self.env['account.move'].search(invoice_domain).mapped('amount_untaxed_signed'))

        # Collection Rate: Collections in period / (Total Outstanding at end + Collections in period)
        collection_denominator = total_outstanding + collections_period
        if collection_denominator > 0:
            collection_rate = round((collections_period / collection_denominator) * 100, 1)
        else:
            collection_rate = 0.0

        # 3. Monthly collection chart (last 6 months)
        monthly_trend = []
        cur_month_start = today.replace(day=1)
        for i in range(5, -1, -1):
            m_start = cur_month_start - relativedelta(months=i)
            m_end = m_start + relativedelta(months=1, days=-1)
            m_label = m_start.strftime('%b %Y')

            m_coll_domain = [
                ('company_id', '=', comp_id),
                ('account_id.account_type', '=', 'asset_receivable'),
                ('move_id.state', '=', 'posted'),
                ('date', '>=', m_start),
                ('date', '<=', m_end),
                ('credit', '>', 0),
                ('move_id.move_type', 'in', ('entry', False)),
            ]
            if br_id:
                m_coll_domain.append(('branch_id', '=', br_id))

            m_amount = sum(self.env['account.move.line'].search(m_coll_domain).mapped('credit'))
            monthly_trend.append({
                'month': m_label,
                'amount': currency.round(m_amount)
            })

        # 4. Top Debtors (Sort by total desc, limit 5)
        top_debtors = sorted(
            [d for d in debtors_map.values() if d['total'] > 0],
            key=lambda x: x['total'],
            reverse=True
        )[:5]
        for d in top_debtors:
            d['total_formatted'] = self._format_currency(d['total'], currency)
            d['overdue_formatted'] = self._format_currency(d['overdue'], currency)

        # 5. Most Overdue Accounts (Sort by overdue desc, limit 5)
        most_overdue = sorted(
            [d for d in overdue_map.values() if d['overdue'] > 0],
            key=lambda x: (x['overdue'], x['max_days']),
            reverse=True
        )[:5]
        for d in most_overdue:
            d['overdue_formatted'] = self._format_currency(d['overdue'], currency)

        # 6. Recent Payments (last 5)
        recent_payment_domain = [
            ('company_id', '=', comp_id),
            ('partner_type', '=', 'customer'),
            ('state', '=', 'posted'),
        ]
        if br_id:
            recent_payment_domain.append(('branch_id', '=', br_id))

        recent_payments_recs = self.env['account.payment'].search(
            recent_payment_domain,
            order='date desc, id desc',
            limit=5
        )
        recent_payments = []
        for p in recent_payments_recs:
            recent_payments.append({
                'id': p.id,
                'name': p.name,
                'partner_name': p.partner_id.name if p.partner_id else _("Unknown"),
                'date': p.date.strftime('%Y-%m-%d'),
                'amount': self._format_currency(p.amount, p.currency_id or currency),
            })

        # 7. Collection Follow-ups (Upcoming next 7 days and Overdue)
        fu_domain = [
            ('company_id', '=', comp_id),
            ('status', 'not in', ('resolved', 'cancelled')),
        ]
        if br_id:
            fu_domain.append(('branch_id', '=', br_id))
        if not self.env.user.has_group('ar_management_dashboard.group_ar_admin'):
            fu_domain.append(('user_id', '=', self.env.user.id))

        followup_recs = self.env['ar.followup'].search(fu_domain, order='followup_date asc', limit=10)

        upcoming_followups = []
        overdue_followups = []
        next_week = today + timedelta(days=7)

        for fu in followup_recs:
            item = {
                'id': fu.id,
                'name': fu.name,
                'partner_name': fu.partner_id.name,
                'followup_date': fu.followup_date.strftime('%Y-%m-%d'),
                'contact_method': dict(fu._fields['contact_method'].selection).get(fu.contact_method, fu.contact_method),
                'priority': fu.priority,
                'status': dict(fu._fields['status'].selection).get(fu.status, fu.status),
                'user_name': fu.user_id.name,
                'promised_amount': self._format_currency(fu.promised_amount, currency) if fu.promised_amount else False,
            }
            if fu.followup_date < today:
                overdue_followups.append(item)
            elif fu.followup_date <= next_week:
                upcoming_followups.append(item)

        return {
            'company_id': comp_id,
            'branch_id': br_id,
            'currency_symbol': currency.symbol,
            'currency_position': currency.position,
            'kpis': {
                'total_outstanding': currency.round(total_outstanding),
                'total_outstanding_fmt': self._format_currency(total_outstanding, currency),
                'overdue_total': currency.round(overdue_total),
                'overdue_total_fmt': self._format_currency(overdue_total, currency),
                'not_due_total': currency.round(not_due_total),
                'not_due_total_fmt': self._format_currency(not_due_total, currency),
                'overdue_90_plus': currency.round(overdue_90_plus),
                'overdue_90_plus_fmt': self._format_currency(overdue_90_plus, currency),
                'collections_period': currency.round(collections_period),
                'collections_period_fmt': self._format_currency(collections_period, currency),
                'total_customers': total_customers,
                'overdue_customers': overdue_customers,
                'collection_rate': collection_rate,
            },
            'aging_distribution': {
                'labels': [_('Not Due'), _('1 - 30 Days'), _('31 - 60 Days'), _('61 - 90 Days'), _('90+ Days')],
                'values': [
                    currency.round(aging_buckets['not_due']),
                    currency.round(aging_buckets['days_1_30']),
                    currency.round(aging_buckets['days_31_60']),
                    currency.round(aging_buckets['days_61_90']),
                    currency.round(aging_buckets['days_over_90']),
                ],
            },
            'monthly_trend': monthly_trend,
            'top_debtors': top_debtors,
            'most_overdue': most_overdue,
            'recent_payments': recent_payments,
            'upcoming_followups': upcoming_followups,
            'overdue_followups': overdue_followups,
        }

    @api.model
    def _format_currency(self, amount, currency):
        if not amount:
            amount = 0.0
        formatted = "{:,.2f}".format(amount)
        if currency.position == 'after':
            return f"{formatted} {currency.symbol}"
        return f"{currency.symbol} {formatted}"

    # Drill-down action methods called from UI cards
    @api.model
    def action_view_outstanding_receivables(self, company_id=None, branch_id=None):
        comp_id, br_id = self._validate_user_scope(company_id, branch_id)
        domain = [
            ('company_id', '=', comp_id),
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('amount_residual', '>', 0),
        ]
        if br_id:
            domain.append(('branch_id', '=', br_id))
        return {
            'name': _('Outstanding Invoices'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'domain': domain,
            'context': {'default_move_type': 'out_invoice'}
        }

    @api.model
    def action_view_overdue_receivables(self, company_id=None, branch_id=None):
        comp_id, br_id = self._validate_user_scope(company_id, branch_id)
        today = fields.Date.context_today(self)
        domain = [
            ('company_id', '=', comp_id),
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('amount_residual', '>', 0),
            ('invoice_date_due', '<', today),
        ]
        if br_id:
            domain.append(('branch_id', '=', br_id))
        return {
            'name': _('Overdue Invoices'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'domain': domain,
            'context': {'default_move_type': 'out_invoice'}
        }

    @api.model
    def action_view_collections(self, company_id=None, branch_id=None, date_from=None, date_to=None):
        comp_id, br_id = self._validate_user_scope(company_id, branch_id)
        domain = [
            ('company_id', '=', comp_id),
            ('partner_type', '=', 'customer'),
            ('state', '=', 'posted'),
        ]
        if br_id:
            domain.append(('branch_id', '=', br_id))
        if date_from:
            domain.append(('date', '>=', date_from))
        if date_to:
            domain.append(('date', '<=', date_to))
        return {
            'name': _('Customer Collections'),
            'type': 'ir.actions.act_window',
            'res_model': 'account.payment',
            'view_mode': 'list,form',
            'domain': domain,
        }

    @api.model
    def action_view_followups(self, company_id=None, branch_id=None, filter_type='all'):
        comp_id, br_id = self._validate_user_scope(company_id, branch_id)
        today = fields.Date.context_today(self)
        domain = [('company_id', '=', comp_id)]
        if br_id:
            domain.append(('branch_id', '=', br_id))
        if not self.env.user.has_group('ar_management_dashboard.group_ar_admin'):
            domain.append(('user_id', '=', self.env.user.id))

        if filter_type == 'overdue':
            domain.extend([('status', 'not in', ('resolved', 'cancelled')), ('followup_date', '<', today)])
        elif filter_type == 'upcoming':
            domain.extend([('status', 'not in', ('resolved', 'cancelled')), ('followup_date', '>=', today), ('followup_date', '<=', today + timedelta(days=7))])

        return {
            'name': _('Collection Follow-ups'),
            'type': 'ir.actions.act_window',
            'res_model': 'ar.followup',
            'view_mode': 'list,form,calendar,kanban',
            'domain': domain,
        }
