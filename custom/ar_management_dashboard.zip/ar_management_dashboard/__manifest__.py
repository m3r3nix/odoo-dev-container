# -*- coding: utf-8 -*-
{
    'name': 'Accounts Receivable (AR) Management Dashboard',
    'version': '19.0.1.0.0',
    'category': 'Accounting/Receivables',
    'summary': 'Comprehensive Accounts Receivable Dashboard, Branch Management, Aging Analysis, and Collection Follow-ups for Odoo 19 Community Edition',
    'description': """
Accounts Receivable (AR) Management Dashboard for Odoo 19 Community Edition
=============================================================================
A complete, enterprise-grade Accounts Receivable management and collection suite
designed specifically for Odoo 19 Community Edition without requiring Enterprise licenses.

Key Highlights:
---------------
* **Interactive AR Dashboard**: Modern OWL 2 dashboard providing real-time KPI metrics,
  aging distribution charts, monthly collection trends, top debtors, and overdue accounts.
* **Strict Multi-Branch Security**: Explicit branch model (`ar.branch`) allowing branch assignment
  to invoices, payments, follow-ups, and partners, with record-level security rules.
* **Accurate Receivables Accounting**: Uses Odoo ORM to calculate true receivables from posted
  `account.move.line` records, handling partial reconciliations, unallocated credit notes,
  multi-currency rates, and historical as-of-date balances.
* **Collection Follow-Up Management**: Track collection activities, scheduling, priority,
  contact methods, promises to pay, and resolutions.
* **Comprehensive Aging Reports**: 5 aging buckets (Not Due, 1-30, 31-60, 61-90, 90+ days overdue)
  with PDF and Excel (XLSX) exports.
* **Customer Account Statements**: Opening balance, running debits and credits, reconciliation-safe
  ledger entries, and closing balance with PDF and XLSX export.
* **Server-Side Security**: Enforced group permissions (`group_ar_admin`, `group_ar_branch_manager`)
  and multi-company/multi-branch record rules.
    """,
    'author': 'Senior Odoo Developer',
    'website': 'https://github.com/Graphify-Labs',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'account',
        'web',
    ],
    'external_dependencies': {
        'python': ['xlsxwriter'],
    },
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/ar_branch_views.xml',
        'views/ar_followup_views.xml',
        'views/res_partner_views.xml',
        'views/ar_aging_wizard_views.xml',
        'views/ar_statement_wizard_views.xml',
        'views/ar_dashboard_views.xml',
        'report/ar_report.xml',
        'report/ar_report_templates.xml',
        'views/ar_menu.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'ar_management_dashboard/static/src/scss/ar_dashboard.scss',
            'ar_management_dashboard/static/src/js/ar_dashboard.js',
            'ar_management_dashboard/static/src/xml/ar_dashboard.xml',
        ],
    },
    'installable': True,
    'application': True,
    'auto_install': False,
}
