# -*- coding: utf-8 -*-
from odoo import models, api, fields, _
from datetime import timedelta


class ReportArAging(models.AbstractModel):
    _name = 'report.ar_management_dashboard.report_ar_aging_template'
    _description = 'AR Aging Report Parser'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['ar.aging.wizard'].browse(docids)
        aging_results = {}
        for wizard in docs:
            aging_results[wizard.id] = wizard._get_aging_lines()

        return {
            'doc_ids': docids,
            'doc_model': 'ar.aging.wizard',
            'docs': docs,
            'aging_results': aging_results,
        }


class ReportArStatement(models.AbstractModel):
    _name = 'report.ar_management_dashboard.report_ar_statement_template'
    _description = 'AR Customer Statement Parser'

    @api.model
    def _get_report_values(self, docids, data=None):
        docs = self.env['ar.statement.wizard'].browse(docids)
        statement_data = {}
        for wizard in docs:
            statement_data[wizard.id] = wizard._get_statement_data()

        return {
            'doc_ids': docids,
            'doc_model': 'ar.statement.wizard',
            'docs': docs,
            'statement_data': statement_data,
        }


class ReportArOutstanding(models.AbstractModel):
    _name = 'report.ar_management_dashboard.report_ar_outstanding_template'
    _description = 'AR Outstanding Invoices Parser'

    @api.model
    def _get_report_values(self, docids, data=None):
        invoices = self.env['account.move'].search([
            ('id', 'in', docids),
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('amount_residual', '>', 0),
        ]) if docids else self.env['account.move'].search([
            ('company_id', 'in', self.env.companies.ids),
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('amount_residual', '>', 0),
        ], order='invoice_date_due asc, partner_id asc', limit=100)

        return {
            'doc_ids': docids,
            'doc_model': 'account.move',
            'docs': invoices,
            'company': self.env.company,
        }


class ReportArOverdue(models.AbstractModel):
    _name = 'report.ar_management_dashboard.report_ar_overdue_template'
    _description = 'AR Overdue Invoices Parser'

    @api.model
    def _get_report_values(self, docids, data=None):
        today = fields.Date.context_today(self)
        domain = [
            ('company_id', 'in', self.env.companies.ids),
            ('move_type', '=', 'out_invoice'),
            ('state', '=', 'posted'),
            ('amount_residual', '>', 0),
            ('invoice_date_due', '<', today),
        ]
        if docids:
            domain.append(('id', 'in', docids))

        invoices = self.env['account.move'].search(domain, order='invoice_date_due asc, partner_id asc', limit=100)

        return {
            'doc_ids': docids,
            'doc_model': 'account.move',
            'docs': invoices,
            'company': self.env.company,
            'today': today,
        }


class ReportArCollectionSummary(models.AbstractModel):
    _name = 'report.ar_management_dashboard.report_ar_collection_summary_template'
    _description = 'AR Collection Summary Parser'

    @api.model
    def _get_report_values(self, docids, data=None):
        today = fields.Date.context_today(self)
        start_month = today.replace(day=1)
        payments = self.env['account.payment'].search([
            ('company_id', 'in', self.env.companies.ids),
            ('partner_type', '=', 'customer'),
            ('state', '=', 'posted'),
            ('date', '>=', start_month),
            ('date', '<=', today),
        ], order='date desc')

        return {
            'doc_ids': docids,
            'doc_model': 'account.payment',
            'docs': payments,
            'company': self.env.company,
            'date_from': start_month,
            'date_to': today,
        }
