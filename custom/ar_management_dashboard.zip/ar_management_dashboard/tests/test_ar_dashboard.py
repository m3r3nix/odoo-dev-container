# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from datetime import date, timedelta


class TestArDashboard(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super(TestArDashboard, cls).setUpClass()
        cls.company = cls.env.company
        cls.currency = cls.company.currency_id

        cls.branch_a = cls.env['ar.branch'].create({
            'name': 'Branch Alpha',
            'code': 'BA-01',
            'company_id': cls.company.id,
        })
        cls.branch_b = cls.env['ar.branch'].create({
            'name': 'Branch Beta',
            'code': 'BB-01',
            'company_id': cls.company.id,
        })

        cls.partner_a = cls.env['res.partner'].create({
            'name': 'Dashboard Customer A',
            'company_id': cls.company.id,
            'branch_id': cls.branch_a.id,
            'customer_rank': 1,
        })

        cls.income_account = cls.env['account.account'].search([
            ('company_id', '=', cls.company.id),
            ('account_type', '=', 'income')
        ], limit=1)

    def _create_invoice(self, partner, branch, amount, due_date):
        move = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': partner.id,
            'branch_id': branch.id,
            'invoice_date': date.today(),
            'invoice_date_due': due_date,
            'company_id': self.company.id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Service Invoice',
                'quantity': 1,
                'price_unit': amount,
                'account_id': self.income_account.id if self.income_account else False,
            })],
        })
        move.action_post()
        return move

    def test_dashboard_kpis_and_metrics(self):
        """Verify the calculation of receivables, overdue amounts, and chart structures."""
        today = date.today()

        # Invoices: 1 current, 1 overdue
        self._create_invoice(self.partner_a, self.branch_a, 4000.0, today + timedelta(days=15))
        self._create_invoice(self.partner_a, self.branch_a, 6000.0, today - timedelta(days=20))

        dashboard = self.env['ar.dashboard']
        data = dashboard.get_dashboard_data(
            company_id=self.company.id,
            branch_id=self.branch_a.id,
            date_from=today.replace(day=1),
            date_to=today
        )

        kpis = data.get('kpis', {})
        self.assertAlmostEqual(kpis.get('total_outstanding'), 10000.0, places=2)
        self.assertAlmostEqual(kpis.get('overdue_total'), 6000.0, places=2)
        self.assertAlmostEqual(kpis.get('not_due_total'), 4000.0, places=2)
        self.assertEqual(kpis.get('total_customers'), 1)
        self.assertEqual(kpis.get('overdue_customers'), 1)

        # Aging distribution chart checks
        dist = data.get('aging_distribution', {})
        self.assertEqual(len(dist.get('labels', [])), 5)
        self.assertEqual(len(dist.get('values', [])), 5)
        self.assertAlmostEqual(dist['values'][0], 4000.0, places=2)  # Not Due
        self.assertAlmostEqual(dist['values'][1], 6000.0, places=2)  # 1-30 Days

        # Monthly trend chart checks
        trend = data.get('monthly_trend', [])
        self.assertEqual(len(trend), 6)

    def test_drilldown_actions(self):
        """Drilldown methods must return valid action dictionaries with appropriate domains."""
        dashboard = self.env['ar.dashboard']

        # Outstanding drilldown
        act_out = dashboard.action_view_outstanding_receivables(company_id=self.company.id)
        self.assertEqual(act_out.get('res_model'), 'account.move')
        self.assertIn(('amount_residual', '>', 0), act_out.get('domain', []))

        # Overdue drilldown
        act_od = dashboard.action_view_overdue_receivables(company_id=self.company.id)
        self.assertEqual(act_od.get('res_model'), 'account.move')

        # Collections drilldown
        act_coll = dashboard.action_view_collections(company_id=self.company.id)
        self.assertEqual(act_coll.get('res_model'), 'account.payment')

        # Follow-ups drilldown
        act_fu = dashboard.action_view_followups(company_id=self.company.id, filter_type='overdue')
        self.assertEqual(act_fu.get('res_model'), 'ar.followup')
