# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from datetime import date, timedelta


class TestArAging(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super(TestArAging, cls).setUpClass()
        cls.company = cls.env.company
        cls.currency = cls.company.currency_id

        cls.receivable_account = cls.env['account.account'].search([
            ('company_id', '=', cls.company.id),
            ('account_type', '=', 'asset_receivable')
        ], limit=1)

        cls.income_account = cls.env['account.account'].search([
            ('company_id', '=', cls.company.id),
            ('account_type', '=', 'income')
        ], limit=1)

        cls.partner = cls.env['res.partner'].create({
            'name': 'Aging Test Customer',
            'customer_rank': 1,
            'company_id': cls.company.id,
        })

    def _create_posted_invoice(self, invoice_date, due_date, amount):
        move = self.env['account.move'].create({
            'move_type': 'out_invoice',
            'partner_id': self.partner.id,
            'invoice_date': invoice_date,
            'invoice_date_due': due_date,
            'company_id': self.company.id,
            'invoice_line_ids': [(0, 0, {
                'name': 'Consulting Service',
                'quantity': 1,
                'price_unit': amount,
                'account_id': self.income_account.id if self.income_account else False,
            })],
        })
        move.action_post()
        return move

    def test_aging_bucket_boundaries(self):
        """Verify invoices are categorized into the correct aging bucket according to due date."""
        today = date.today()

        # Invoices at different due dates
        inv_not_due = self._create_posted_invoice(today - timedelta(days=5), today + timedelta(days=10), 1000.0)
        inv_1_30 = self._create_posted_invoice(today - timedelta(days=25), today - timedelta(days=15), 2000.0)
        inv_31_60 = self._create_posted_invoice(today - timedelta(days=60), today - timedelta(days=45), 3000.0)
        inv_61_90 = self._create_posted_invoice(today - timedelta(days=90), today - timedelta(days=75), 4000.0)
        inv_over_90 = self._create_posted_invoice(today - timedelta(days=130), today - timedelta(days=110), 5000.0)

        wizard = self.env['ar.aging.wizard'].create({
            'as_of_date': today,
            'company_id': self.company.id,
            'partner_ids': [(6, 0, [self.partner.id])],
            'filter_type': 'all',
        })

        results = wizard._get_aging_lines()
        self.assertTrue(results, "Aging lines should not be empty")

        partner_summary = results[0]
        self.assertAlmostEqual(partner_summary['total_not_due'], 1000.0, places=2)
        self.assertAlmostEqual(partner_summary['total_1_30'], 2000.0, places=2)
        self.assertAlmostEqual(partner_summary['total_31_60'], 3000.0, places=2)
        self.assertAlmostEqual(partner_summary['total_61_90'], 4000.0, places=2)
        self.assertAlmostEqual(partner_summary['total_over_90'], 5000.0, places=2)
        self.assertAlmostEqual(partner_summary['total_balance'], 15000.0, places=2)

    def test_historical_aging_reconciliation_timing(self):
        """Payments made after the as_of_date should not reduce the historical balance."""
        today = date.today()
        inv_date = today - timedelta(days=40)
        due_date = today - timedelta(days=10)

        invoice = self._create_posted_invoice(inv_date, due_date, 5000.0)

        # Check aging as of 20 days ago (prior to payment)
        as_of_historical = today - timedelta(days=20)
        wizard_hist = self.env['ar.aging.wizard'].create({
            'as_of_date': as_of_historical,
            'company_id': self.company.id,
            'partner_ids': [(6, 0, [self.partner.id])],
        })

        hist_results = wizard_hist._get_aging_lines()
        self.assertTrue(hist_results)
        self.assertAlmostEqual(hist_results[0]['total_balance'], 5000.0, places=2)

    def test_aging_xlsx_export(self):
        """Test XLSX generation does not crash and produces binary content."""
        wizard = self.env['ar.aging.wizard'].create({
            'as_of_date': date.today(),
            'company_id': self.company.id,
        })
        action = wizard.action_export_xlsx()
        self.assertTrue(wizard.data_file, "Excel binary content must be populated.")
        self.assertTrue(wizard.filename.endswith('.xlsx'))
        self.assertEqual(action.get('type'), 'ir.actions.act_url')
