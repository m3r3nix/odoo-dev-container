# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from odoo.exceptions import UserError
from datetime import date, timedelta


class TestArFollowup(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super(TestArFollowup, cls).setUpClass()
        cls.company = cls.env.company
        cls.branch = cls.env['ar.branch'].create({
            'name': 'Test Collection Branch',
            'code': 'TCB-01',
            'company_id': cls.company.id,
        })
        cls.partner = cls.env['res.partner'].create({
            'name': 'Followup Test Partner',
            'company_id': cls.company.id,
            'branch_id': cls.branch.id,
            'phone': '+1234567890',
            'email': 'partner@test.com',
        })

    def test_followup_lifecycle(self):
        """Verify the progression of follow-up statuses and promise to pay validation."""
        today = date.today()

        followup = self.env['ar.followup'].create({
            'partner_id': self.partner.id,
            'company_id': self.company.id,
            'branch_id': self.branch.id,
            'followup_date': today,
            'contact_method': 'phone',
            'priority': '2',
            'notes': 'Initial follow-up call scheduled.',
        })

        self.assertEqual(followup.status, 'planned')
        self.assertFalse(followup.is_overdue)

        # Start work
        followup.action_set_in_progress()
        self.assertEqual(followup.status, 'in_progress')

        # Contacted
        followup.action_set_contacted()
        self.assertEqual(followup.status, 'contacted')

        # Attempt promise to pay without promised date -> must raise UserError
        with self.assertRaises(UserError):
            followup.action_set_promise_to_pay()

        # Set promised payment date and amount
        followup.write({
            'promised_amount': 2500.0,
            'promised_date': today + timedelta(days=7),
        })
        followup.action_set_promise_to_pay()
        self.assertEqual(followup.status, 'promise_to_pay')

        # Resolve
        followup.action_set_resolved()
        self.assertEqual(followup.status, 'resolved')
        self.assertFalse(followup.is_overdue)

    def test_followup_overdue_computation(self):
        """Follow-up with a past date that is not resolved or cancelled must be marked overdue."""
        yesterday = date.today() - timedelta(days=1)
        followup = self.env['ar.followup'].create({
            'partner_id': self.partner.id,
            'company_id': self.company.id,
            'followup_date': yesterday,
            'status': 'planned',
        })
        self.assertTrue(followup.is_overdue)

        # Once resolved, is_overdue becomes False
        followup.action_set_resolved()
        self.assertFalse(followup.is_overdue)

    def test_partner_followup_integration(self):
        """Partner model should reflect linked follow-up counts and history."""
        initial_count = self.partner.ar_followup_count

        self.env['ar.followup'].create({
            'partner_id': self.partner.id,
            'company_id': self.company.id,
            'followup_date': date.today(),
            'status': 'planned',
        })

        self.partner._compute_ar_counts()
        self.assertEqual(self.partner.ar_followup_count, initial_count + 1)
