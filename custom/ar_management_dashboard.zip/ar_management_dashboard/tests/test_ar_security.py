# -*- coding: utf-8 -*-
from odoo.tests.common import TransactionCase
from odoo.exceptions import AccessError, ValidationError


class TestArSecurity(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super(TestArSecurity, cls).setUpClass()
        cls.company_1 = cls.env['res.company'].create({'name': 'Company Alpha'})
        cls.company_2 = cls.env['res.company'].create({'name': 'Company Beta'})

        # Groups
        cls.group_admin = cls.env.ref('ar_management_dashboard.group_ar_admin')
        cls.group_manager = cls.env.ref('ar_management_dashboard.group_ar_branch_manager')

        # Branches
        cls.branch_north = cls.env['ar.branch'].create({
            'name': 'North Branch',
            'code': 'NB-01',
            'company_id': cls.company_1.id,
        })
        cls.branch_south = cls.env['ar.branch'].create({
            'name': 'South Branch',
            'code': 'SB-01',
            'company_id': cls.company_1.id,
        })

        # Users
        cls.user_admin = cls.env['res.users'].create({
            'name': 'Admin User',
            'login': 'ar_admin_test',
            'email': 'admin@test.com',
            'company_id': cls.company_1.id,
            'company_ids': [(6, 0, [cls.company_1.id, cls.company_2.id])],
            'groups_id': [(6, 0, [cls.group_admin.id])],
        })

        cls.user_north_manager = cls.env['res.users'].create({
            'name': 'North Branch Manager',
            'login': 'ar_north_mgr_test',
            'email': 'north@test.com',
            'company_id': cls.company_1.id,
            'company_ids': [(6, 0, [cls.company_1.id])],
            'groups_id': [(6, 0, [cls.group_manager.id])],
            'branch_ids': [(6, 0, [cls.branch_north.id])],
        })

        # Link North manager
        cls.branch_north.write({'manager_ids': [(4, cls.user_north_manager.id)]})

        # Customers
        cls.partner_north = cls.env['res.partner'].create({
            'name': 'North Customer',
            'company_id': cls.company_1.id,
            'branch_id': cls.branch_north.id,
        })
        cls.partner_south = cls.env['res.partner'].create({
            'name': 'South Customer',
            'company_id': cls.company_1.id,
            'branch_id': cls.branch_south.id,
        })

    def test_branch_unique_code_per_company(self):
        """Branch code must be unique within the same company."""
        with self.assertRaises(ValidationError):
            self.env['ar.branch'].create({
                'name': 'Duplicate Code Branch',
                'code': 'NB-01',
                'company_id': self.company_1.id,
            })

    def test_branch_manager_scope_restriction(self):
        """Branch manager can only see authorized branch records."""
        BranchEnv = self.env['ar.branch'].with_user(self.user_north_manager)
        branches = BranchEnv.search([])
        self.assertIn(self.branch_north, branches)
        self.assertNotIn(self.branch_south, branches)

    def test_admin_global_branch_access(self):
        """Admin can view all branches across permitted companies."""
        BranchEnv = self.env['ar.branch'].with_user(self.user_admin)
        branches = BranchEnv.search([])
        self.assertIn(self.branch_north, branches)
        self.assertIn(self.branch_south, branches)

    def test_followup_branch_security(self):
        """Branch manager cannot read or update follow-ups belonging to other branches."""
        fu_south = self.env['ar.followup'].create({
            'partner_id': self.partner_south.id,
            'company_id': self.company_1.id,
            'branch_id': self.branch_south.id,
            'followup_date': '2026-10-20',
            'contact_method': 'phone',
            'priority': '1',
            'status': 'planned',
        })

        FollowupEnv = self.env['ar.followup'].with_user(self.user_north_manager)
        visible_followups = FollowupEnv.search([('id', '=', fu_south.id)])
        self.assertFalse(visible_followups, "Branch manager must not see followups for unassigned branches.")

    def test_dashboard_server_side_validation(self):
        """Server-side scope validation rejects unauthorized branch queries."""
        DashboardEnv = self.env['ar.dashboard'].with_user(self.user_north_manager)
        with self.assertRaises(AccessError):
            DashboardEnv.get_dashboard_data(
                company_id=self.company_1.id,
                branch_id=self.branch_south.id
            )
