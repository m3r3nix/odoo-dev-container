# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, AccessError, ValidationError
import base64
import io

try:
    import xlsxwriter
except ImportError:
    xlsxwriter = None


class ArStatementWizard(models.TransientModel):
    _name = 'ar.statement.wizard'
    _description = 'Customer Account Statement Wizard'

    partner_id = fields.Many2one(
        'res.partner',
        string='Customer',
        required=True,
        help="Customer whose account statement is to be generated."
    )
    date_from = fields.Date(
        string='Start Date',
        required=True,
        default=lambda self: fields.Date.context_today(self).replace(day=1),
        help="Statement period start date."
    )
    date_to = fields.Date(
        string='End Date',
        required=True,
        default=fields.Date.context_today,
        help="Statement period end date."
    )
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company
    )
    branch_id = fields.Many2one(
        'ar.branch',
        string='Branch',
        domain="[('company_id', '=', company_id)]",
        help="Optional branch filter."
    )
    currency_id = fields.Many2one(
        'res.currency',
        string='Currency',
        default=lambda self: self.env.company.currency_id,
        help="Currency for displaying balances."
    )

    data_file = fields.Binary(string='Statement File', readonly=True)
    filename = fields.Char(string='Filename', readonly=True)

    @api.constrains('date_from', 'date_to')
    def _check_dates(self):
        for rec in self:
            if rec.date_from and rec.date_to and rec.date_from > rec.date_to:
                raise ValidationError(_("Start Date cannot be later than End Date."))

    def _validate_scope(self):
        user = self.env.user
        if self.company_id.id not in self.env.companies.ids:
            raise AccessError(_("You are not authorized to access this company."))
        if self.branch_id and not user.has_group('ar_management_dashboard.group_ar_admin'):
            if self.branch_id.id not in user.branch_ids.ids:
                raise AccessError(_("You are not authorized to view the selected branch."))

    def _get_statement_data(self):
        """
        Calculates Opening Balance, period ledger transactions, and Closing Balance.
        Uses posted account.move.line for asset_receivable accounts to avoid double-counting.
        """
        self._validate_scope()
        comp_id = self.company_id.id
        p_id = self.partner_id.id
        MoveLine = self.env['account.move.line']

        # 1. Opening Balance prior to date_from
        opening_domain = [
            ('company_id', '=', comp_id),
            ('partner_id', '=', p_id),
            ('account_id.account_type', '=', 'asset_receivable'),
            ('move_id.state', '=', 'posted'),
            ('date', '<', self.date_from),
        ]
        if self.branch_id:
            opening_domain.append(('branch_id', '=', self.branch_id.id))

        opening_lines = MoveLine.search(opening_domain)
        opening_balance = sum(opening_lines.mapped('balance'))

        # 2. Period Transactions between date_from and date_to
        period_domain = [
            ('company_id', '=', comp_id),
            ('partner_id', '=', p_id),
            ('account_id.account_type', '=', 'asset_receivable'),
            ('move_id.state', '=', 'posted'),
            ('date', '>=', self.date_from),
            ('date', '<=', self.date_to),
        ]
        if self.branch_id:
            period_domain.append(('branch_id', '=', self.branch_id.id))

        period_lines = MoveLine.search(period_domain, order='date asc, id asc')

        running_balance = opening_balance
        transactions = []
        total_debit = 0.0
        total_credit = 0.0

        for line in period_lines:
            debit = line.debit
            credit = line.credit
            running_balance += (debit - credit)
            total_debit += debit
            total_credit += credit

            trans_type = _("Journal Entry")
            if line.move_id.move_type == 'out_invoice':
                trans_type = _("Customer Invoice")
            elif line.move_id.move_type == 'out_refund':
                trans_type = _("Credit Note")
            elif line.payment_id or line.move_id.payment_id:
                trans_type = _("Payment")

            transactions.append({
                'id': line.id,
                'date': line.date,
                'due_date': line.date_maturity or line.date,
                'move_name': line.move_id.name or line.name,
                'ref': line.move_id.ref or line.ref or '',
                'type': trans_type,
                'branch': line.branch_id.name if line.branch_id else '',
                'debit': debit,
                'credit': credit,
                'balance': running_balance,
            })

        closing_balance = running_balance

        return {
            'partner': self.partner_id,
            'company': self.company_id,
            'branch': self.branch_id,
            'date_from': self.date_from,
            'date_to': self.date_to,
            'currency': self.currency_id,
            'opening_balance': opening_balance,
            'total_debit': total_debit,
            'total_credit': total_credit,
            'closing_balance': closing_balance,
            'transactions': transactions,
        }

    def action_print_pdf(self):
        self.ensure_one()
        return self.env.ref('ar_management_dashboard.action_report_ar_statement').report_action(self)

    def action_export_xlsx(self):
        self.ensure_one()
        if not xlsxwriter:
            raise UserError(_("The 'xlsxwriter' Python module is required for Excel export. Please run: pip install xlsxwriter"))

        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet(_('Account Statement'))

        title_fmt = workbook.add_format({'bold': True, 'font_size': 14, 'color': '#1E3A8A'})
        header_fmt = workbook.add_format({'bold': True, 'bg_color': '#2563EB', 'font_color': '#FFFFFF', 'border': 1, 'align': 'center'})
        num_fmt = workbook.add_format({'num_format': '#,##0.00', 'border': 1})
        bold_num_fmt = workbook.add_format({'bold': True, 'num_format': '#,##0.00', 'border': 1, 'bg_color': '#F1F5F9'})
        text_fmt = workbook.add_format({'border': 1})
        date_fmt = workbook.add_format({'num_format': 'yyyy-mm-dd', 'border': 1, 'align': 'center'})

        stmt = self._get_statement_data()

        # Header information
        sheet.write(0, 0, _("CUSTOMER ACCOUNT STATEMENT"), title_fmt)
        sheet.write(1, 0, f"Customer: {self.partner_id.name} ({self.partner_id.ref or 'No Ref'})")
        sheet.write(2, 0, f"Period: {self.date_from} to {self.date_to} | Company: {self.company_id.name}")
        if self.branch_id:
            sheet.write(3, 0, f"Branch: {self.branch_id.name}")

        # Table Headers
        headers = [_("Date"), _("Document"), _("Reference"), _("Type"), _("Due Date"), _("Debit"), _("Credit"), _("Balance")]
        row = 5
        for col, h in enumerate(headers):
            sheet.write(row, col, h, header_fmt)

        # Opening balance row
        row += 1
        sheet.write(row, 0, self.date_from.strftime('%Y-%m-%d'), date_fmt)
        sheet.write(row, 1, _("OPENING BALANCE"), text_fmt)
        sheet.write(row, 2, "", text_fmt)
        sheet.write(row, 3, "", text_fmt)
        sheet.write(row, 4, "", text_fmt)
        sheet.write(row, 5, 0.0, num_fmt)
        sheet.write(row, 6, 0.0, num_fmt)
        sheet.write(row, 7, stmt['opening_balance'], bold_num_fmt)

        row += 1
        for tr in stmt['transactions']:
            sheet.write(row, 0, tr['date'].strftime('%Y-%m-%d') if tr['date'] else '', date_fmt)
            sheet.write(row, 1, tr['move_name'], text_fmt)
            sheet.write(row, 2, tr['ref'], text_fmt)
            sheet.write(row, 3, tr['type'], text_fmt)
            sheet.write(row, 4, tr['due_date'].strftime('%Y-%m-%d') if tr['due_date'] else '', date_fmt)
            sheet.write(row, 5, tr['debit'], num_fmt)
            sheet.write(row, 6, tr['credit'], num_fmt)
            sheet.write(row, 7, tr['balance'], num_fmt)
            row += 1

        # Summary rows
        row += 1
        sheet.write(row, 0, _("TOTAL ACTIVITY"), header_fmt)
        for c in range(1, 5):
            sheet.write(row, c, "", header_fmt)
        sheet.write(row, 5, stmt['total_debit'], bold_num_fmt)
        sheet.write(row, 6, stmt['total_credit'], bold_num_fmt)
        sheet.write(row, 7, stmt['closing_balance'], bold_num_fmt)

        row += 1
        sheet.write(row, 0, _("CLOSING BALANCE"), workbook.add_format({'bold': True, 'bg_color': '#DBEAFE', 'border': 1}))
        for c in range(1, 7):
            sheet.write(row, c, "", workbook.add_format({'bold': True, 'bg_color': '#DBEAFE', 'border': 1}))
        sheet.write(row, 7, stmt['closing_balance'], workbook.add_format({'bold': True, 'bg_color': '#DBEAFE', 'border': 1, 'num_format': '#,##0.00'}))

        sheet.set_column(0, 0, 12)
        sheet.set_column(1, 1, 20)
        sheet.set_column(2, 2, 16)
        sheet.set_column(3, 3, 18)
        sheet.set_column(4, 4, 12)
        sheet.set_column(5, 7, 16)

        workbook.close()
        output.seek(0)
        file_data = base64.b64encode(output.read())
        output.close()

        self.write({
            'data_file': file_data,
            'filename': f"Statement_{self.partner_id.name}_{self.date_from}_{self.date_to}.xlsx"
        })

        return {
            'type': 'ir.actions.act_url',
            'url': f"/web/content/?model=ar.statement.wizard&id={self.id}&field=data_file&download=true&filename={self.filename}",
            'target': 'self',
        }
