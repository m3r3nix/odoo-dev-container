# -*- coding: utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import UserError, AccessError, ValidationError
import base64
import io

try:
    import xlsxwriter
except ImportError:
    xlsxwriter = None


class ArAgingWizard(models.TransientModel):
    _name = 'ar.aging.wizard'
    _description = 'Accounts Receivable Aging Analysis Wizard'

    as_of_date = fields.Date(
        string='As of Date',
        required=True,
        default=fields.Date.context_today,
        help="Calculate receivables and aging buckets as of this date."
    )
    company_id = fields.Many2one(
        'res.company',
        string='Company',
        required=True,
        default=lambda self: self.env.company
    )
    branch_id = fields.Many2one(
        'ar.branch',
        string='Branch',
        domain="[('company_id', '=', company_id)]",
        help="Optional branch filter. Only shows transactions associated with this branch."
    )
    partner_ids = fields.Many2many(
        'res.partner',
        string='Customers',
        help="Leave blank to include all customers with open balances."
    )
    filter_type = fields.Selection(
        [
            ('all', 'All Open Receivables'),
            ('overdue', 'Overdue Accounts Only'),
        ],
        string='Filter Receivables',
        default='all',
        required=True
    )
    include_subtotals = fields.Boolean(
        string='Include Customer Subtotals',
        default=True
    )

    # Output fields for download
    data_file = fields.Binary(string='Report File', readonly=True)
    filename = fields.Char(string='Filename', readonly=True)

    @api.model
    def default_get(self, fields_list):
        res = super(ArAgingWizard, self).default_get(fields_list)
        # If user is branch manager without admin rights, prefill their primary branch
        user = self.env.user
        if not user.has_group('ar_management_dashboard.group_ar_admin') and user.branch_ids:
            res['branch_id'] = user.branch_ids[0].id
        return res

    def _validate_scope(self):
        user = self.env.user
        if self.company_id.id not in self.env.companies.ids:
            raise AccessError(_("You are not authorized to run reports for this company."))
        if self.branch_id:
            if not user.has_group('ar_management_dashboard.group_ar_admin'):
                if self.branch_id.id not in user.branch_ids.ids:
                    raise AccessError(_("You are not authorized to view the selected branch."))

    def _get_aging_lines(self):
        """
        Calculates exact historical aging as of self.as_of_date.
        For each posted receivable line dated on or before as_of_date:
        - Determine original amount in company currency.
        - Subtract partial reconciliations that occurred ON OR BEFORE as_of_date.
        - Reconciliations created after as_of_date are ignored (remains unpaid as of that date).
        - Bucket into: Not Due, 1-30, 31-60, 61-90, 90+ days overdue.
        """
        self._validate_scope()
        as_of = self.as_of_date
        comp_id = self.company_id.id
        today = fields.Date.context_today(self)
        is_today = (as_of == today)

        domain = [
            ('company_id', '=', comp_id),
            ('account_id.account_type', '=', 'asset_receivable'),
            ('move_id.state', '=', 'posted'),
            ('date', '<=', as_of),
        ]
        if self.branch_id:
            domain.append(('branch_id', '=', self.branch_id.id))
        if self.partner_ids:
            domain.append(('partner_id', 'in', self.partner_ids.ids))

        lines = self.env['account.move.line'].search(domain, order='partner_id, date, id')
        result_by_partner = {}

        for line in lines:
            partner = line.partner_id
            p_id = partner.id if partner else 0
            p_name = partner.name if partner else _("Unassigned Customer")

            # Determine residual as of date
            if is_today:
                residual = line.amount_residual
            else:
                # Historical calculation
                initial_balance = line.balance
                # Deduct matched credits (if line was debit) or matched debits (if line was credit)
                reconciled_amount = 0.0
                if line.debit > 0:
                    for pr in line.matched_credit_ids:
                        # max_date is the date of the reconciliation
                        pr_date = getattr(pr, 'max_date', pr.create_date.date() if pr.create_date else line.date)
                        if pr_date <= as_of:
                            reconciled_amount += pr.amount
                    residual = initial_balance - reconciled_amount
                else:
                    for pr in line.matched_debit_ids:
                        pr_date = getattr(pr, 'max_date', pr.create_date.date() if pr.create_date else line.date)
                        if pr_date <= as_of:
                            reconciled_amount += pr.amount
                    residual = initial_balance + reconciled_amount

            # Skip fully settled entries as of this date
            if abs(residual) < 0.001:
                continue

            due_date = line.date_maturity or line.date
            days_overdue = (as_of - due_date).days if due_date else 0

            # Filter if overdue accounts only
            if self.filter_type == 'overdue' and days_overdue <= 0:
                continue

            # Classify into buckets
            bucket_not_due = residual if days_overdue <= 0 else 0.0
            bucket_1_30 = residual if 1 <= days_overdue <= 30 else 0.0
            bucket_31_60 = residual if 31 <= days_overdue <= 60 else 0.0
            bucket_61_90 = residual if 61 <= days_overdue <= 90 else 0.0
            bucket_over_90 = residual if days_overdue > 90 else 0.0

            invoice_info = {
                'line_id': line.id,
                'move_id': line.move_id.id,
                'move_name': line.move_id.name or line.name,
                'ref': line.move_id.ref or '',
                'branch_name': line.branch_id.name if line.branch_id else '',
                'invoice_date': line.date,
                'due_date': due_date,
                'currency_symbol': line.currency_id.symbol if line.currency_id else self.company_id.currency_id.symbol,
                'original_amount': line.balance,
                'paid_amount': line.balance - residual,
                'balance': residual,
                'days_overdue': max(0, days_overdue),
                'not_due': bucket_not_due,
                'days_1_30': bucket_1_30,
                'days_31_60': bucket_31_60,
                'days_61_90': bucket_61_90,
                'days_over_90': bucket_over_90,
            }

            if p_id not in result_by_partner:
                result_by_partner[p_id] = {
                    'partner_id': p_id,
                    'partner_name': p_name,
                    'invoices': [],
                    'total_balance': 0.0,
                    'total_not_due': 0.0,
                    'total_1_30': 0.0,
                    'total_31_60': 0.0,
                    'total_61_90': 0.0,
                    'total_over_90': 0.0,
                }

            result_by_partner[p_id]['invoices'].append(invoice_info)
            result_by_partner[p_id]['total_balance'] += residual
            result_by_partner[p_id]['total_not_due'] += bucket_not_due
            result_by_partner[p_id]['total_1_30'] += bucket_1_30
            result_by_partner[p_id]['total_31_60'] += bucket_31_60
            result_by_partner[p_id]['total_61_90'] += bucket_61_90
            result_by_partner[p_id]['total_over_90'] += bucket_over_90

        return list(result_by_partner.values())

    def action_print_pdf(self):
        self.ensure_one()
        return self.env.ref('ar_management_dashboard.action_report_ar_aging').report_action(self)

    def action_export_xlsx(self):
        self.ensure_one()
        if not xlsxwriter:
            raise UserError(_("The 'xlsxwriter' Python module is required for Excel export. Please run: pip install xlsxwriter"))

        output = io.BytesIO()
        workbook = xlsxwriter.Workbook(output, {'in_memory': True})
        sheet = workbook.add_worksheet(_('AR Aging'))

        # Formats
        title_fmt = workbook.add_format({'bold': True, 'font_size': 14, 'color': '#1E3A8A'})
        header_fmt = workbook.add_format({'bold': True, 'bg_color': '#2563EB', 'font_color': '#FFFFFF', 'border': 1, 'align': 'center'})
        subtotal_fmt = workbook.add_format({'bold': True, 'bg_color': '#F1F5F9', 'border': 1, 'num_format': '#,##0.00'})
        total_fmt = workbook.add_format({'bold': True, 'bg_color': '#DBEAFE', 'border': 1, 'num_format': '#,##0.00'})
        num_fmt = workbook.add_format({'num_format': '#,##0.00', 'border': 1})
        text_fmt = workbook.add_format({'border': 1})
        date_fmt = workbook.add_format({'num_format': 'yyyy-mm-dd', 'border': 1, 'align': 'center'})

        # Title
        sheet.write(0, 0, _("Accounts Receivable Aging Report"), title_fmt)
        sheet.write(1, 0, _("As of Date: %s | Company: %s", self.as_of_date, self.company_id.name))
        if self.branch_id:
            sheet.write(2, 0, _("Branch: %s", self.branch_id.name))

        headers = [
            _("Customer / Invoice"), _("Reference"), _("Invoice Date"), _("Due Date"),
            _("Days Overdue"), _("Original Amount"), _("Balance"), _("Not Due"),
            _("1-30 Days"), _("31-60 Days"), _("61-90 Days"), _("90+ Days")
        ]

        row = 4
        for col, h in enumerate(headers):
            sheet.write(row, col, h, header_fmt)

        aging_data = self._get_aging_lines()
        grand_total = 0.0
        grand_not_due = 0.0
        grand_1_30 = 0.0
        grand_31_60 = 0.0
        grand_61_90 = 0.0
        grand_over_90 = 0.0

        row += 1
        for partner_data in aging_data:
            # Partner header row
            sheet.merge_range(row, 0, row, 11, partner_data['partner_name'], workbook.add_format({'bold': True, 'bg_color': '#E2E8F0'}))
            row += 1

            for inv in partner_data['invoices']:
                sheet.write(row, 0, inv['move_name'], text_fmt)
                sheet.write(row, 1, inv['ref'], text_fmt)
                sheet.write(row, 2, inv['invoice_date'].strftime('%Y-%m-%d') if inv['invoice_date'] else '', date_fmt)
                sheet.write(row, 3, inv['due_date'].strftime('%Y-%m-%d') if inv['due_date'] else '', date_fmt)
                sheet.write(row, 4, inv['days_overdue'], text_fmt)
                sheet.write(row, 5, inv['original_amount'], num_fmt)
                sheet.write(row, 6, inv['balance'], num_fmt)
                sheet.write(row, 7, inv['not_due'], num_fmt)
                sheet.write(row, 8, inv['days_1_30'], num_fmt)
                sheet.write(row, 9, inv['days_31_60'], num_fmt)
                sheet.write(row, 10, inv['days_61_90'], num_fmt)
                sheet.write(row, 11, inv['days_over_90'], num_fmt)
                row += 1

            # Subtotal row
            if self.include_subtotals:
                sheet.write(row, 0, _("Subtotal - %s", partner_data['partner_name']), subtotal_fmt)
                for c in range(1, 6):
                    sheet.write(row, c, "", subtotal_fmt)
                sheet.write(row, 6, partner_data['total_balance'], subtotal_fmt)
                sheet.write(row, 7, partner_data['total_not_due'], subtotal_fmt)
                sheet.write(row, 8, partner_data['total_1_30'], subtotal_fmt)
                sheet.write(row, 9, partner_data['total_31_60'], subtotal_fmt)
                sheet.write(row, 10, partner_data['total_61_90'], subtotal_fmt)
                sheet.write(row, 11, partner_data['total_over_90'], subtotal_fmt)
                row += 1

            grand_total += partner_data['total_balance']
            grand_not_due += partner_data['total_not_due']
            grand_1_30 += partner_data['total_1_30']
            grand_31_60 += partner_data['total_31_60']
            grand_61_90 += partner_data['total_61_90']
            grand_over_90 += partner_data['total_over_90']

        # Grand Total Row
        row += 1
        sheet.write(row, 0, _("Grand Total"), total_fmt)
        for c in range(1, 6):
            sheet.write(row, c, "", total_fmt)
        sheet.write(row, 6, grand_total, total_fmt)
        sheet.write(row, 7, grand_not_due, total_fmt)
        sheet.write(row, 8, grand_1_30, total_fmt)
        sheet.write(row, 9, grand_31_60, total_fmt)
        sheet.write(row, 10, grand_61_90, total_fmt)
        sheet.write(row, 11, grand_over_90, total_fmt)

        sheet.set_column(0, 0, 25)
        sheet.set_column(1, 1, 15)
        sheet.set_column(2, 3, 12)
        sheet.set_column(4, 4, 12)
        sheet.set_column(5, 11, 14)

        workbook.close()
        output.seek(0)
        file_data = base64.b64encode(output.read())
        output.close()

        self.write({
            'data_file': file_data,
            'filename': f"AR_Aging_{self.as_of_date}.xlsx"
        })

        return {
            'type': 'ir.actions.act_url',
            'url': f"/web/content/?model=ar.aging.wizard&id={self.id}&field=data_file&download=true&filename={self.filename}",
            'target': 'self',
        }
