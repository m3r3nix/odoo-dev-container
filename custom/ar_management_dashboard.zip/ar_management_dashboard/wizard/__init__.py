# -*- coding: utf-8 -*-
from . import ar_aging_wizard
from . import ar_statement_wizard
