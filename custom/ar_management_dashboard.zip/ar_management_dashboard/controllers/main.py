# -*- coding: utf-8 -*-
from odoo import http, _
from odoo.http import request, content_disposition
from odoo.exceptions import AccessError, UserError
import json


class ArDashboardController(http.Controller):

    def _check_ar_access(self):
        """Ensure the user belongs to either AR Admin or AR Branch Manager."""
        user = request.env.user
        if not (user.has_group('ar_management_dashboard.group_ar_admin') or
                user.has_group('ar_management_dashboard.group_ar_branch_manager')):
            raise AccessError(_("You do not have permission to access Accounts Receivable data."))

    @http.route('/ar_dashboard/fetch_data', type='json', auth='user', methods=['POST'])
    def fetch_dashboard_data(self, company_id=None, branch_id=None, date_from=None, date_to=None):
        """
        JSON-RPC endpoint for retrieving dashboard KPI metrics and chart datasets.
        Requires active user session and validates branch/company access server-side.
        """
        self._check_ar_access()
        dashboard_service = request.env['ar.dashboard']
        data = dashboard_service.get_dashboard_data(
            company_id=company_id,
            branch_id=branch_id,
            date_from=date_from,
            date_to=date_to
        )
        return data

    @http.route('/ar_dashboard/user_context', type='json', auth='user', methods=['POST'])
    def fetch_user_context(self):
        """Returns companies and branches authorized for the current user."""
        self._check_ar_access()
        return request.env['ar.dashboard'].get_user_context_info()

    @http.route('/ar_dashboard/export_excel', type='http', auth='user', methods=['GET'])
    def export_excel(self, wizard_model, wizard_id):
        """
        Secure download endpoint for generated XLSX reports.
        Validates that the user is authorized to view the requested wizard data.
        """
        self._check_ar_access()
        if wizard_model not in ('ar.aging.wizard', 'ar.statement.wizard'):
            raise UserError(_("Invalid report wizard model specified."))

        wizard = request.env[wizard_model].browse(int(wizard_id))
        if not wizard.exists():
            raise UserError(_("The requested report file does not exist."))

        # Enforce multi-company / branch permission check on the wizard record
        wizard._validate_scope()

        if not wizard.data_file:
            raise UserError(_("File data not found. Please regenerate the report."))

        import base64
        filecontent = base64.b64decode(wizard.data_file)
        filename = wizard.filename or 'report.xlsx'

        return request.make_response(
            filecontent,
            headers=[
                ('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                ('Content-Disposition', content_disposition(filename))
            ]
        )
