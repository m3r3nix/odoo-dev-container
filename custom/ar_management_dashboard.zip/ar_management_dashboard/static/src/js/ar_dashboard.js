/** @odoo-module **/

import { Component, useState, onWillStart, onMounted, useRef } from "@odoo/owl";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";

export class ArDashboard extends Component {
    static template = "ar_management_dashboard.DashboardTemplate";

    setup() {
        this.orm = useService("orm");
        this.action = useService("action");
        this.notification = useService("notification");

        this.monthlyChartRef = useRef("monthlyChartRef");
        this.agingChartRef = useRef("agingChartRef");

        this.monthlyChart = null;
        this.agingChart = null;

        // Default date range: start of current month to today
        const now = new Date();
        const year = now.getFullYear();
        const month = String(now.getMonth() + 1).padStart(2, "0");
        const day = String(now.getDate()).padStart(2, "0");
        const firstDayOfMonth = `${year}-${month}-01`;
        const todayStr = `${year}-${month}-${day}`;

        this.state = useState({
            isLoading: true,
            selectedCompanyId: null,
            selectedBranchId: "",
            dateFrom: firstDayOfMonth,
            dateTo: todayStr,
            contextInfo: {
                companies: [],
                branches: [],
                is_admin: false,
                currency_symbol: "",
            },
            data: {
                kpis: {},
                aging_distribution: { labels: [], values: [] },
                monthly_trend: [],
                top_debtors: [],
                most_overdue: [],
                recent_payments: [],
                upcoming_followups: [],
                overdue_followups: [],
            },
        });

        onWillStart(async () => {
            await this.loadUserContext();
            await this.loadDashboardData();
        });

        onMounted(() => {
            this.renderCharts();
        });
    }

    async loadUserContext() {
        try {
            const contextInfo = await this.orm.call("ar.dashboard", "get_user_context_info", []);
            this.state.contextInfo = contextInfo;
            this.state.selectedCompanyId = contextInfo.current_company_id;
        } catch (error) {
            console.error("Error loading user context:", error);
        }
    }

    async loadDashboardData() {
        this.state.isLoading = true;
        try {
            const data = await this.orm.call("ar.dashboard", "get_dashboard_data", [], {
                company_id: this.state.selectedCompanyId ? parseInt(this.state.selectedCompanyId) : null,
                branch_id: this.state.selectedBranchId ? parseInt(this.state.selectedBranchId) : null,
                date_from: this.state.dateFrom,
                date_to: this.state.dateTo,
            });
            this.state.data = data;
        } catch (error) {
            console.error("Error loading AR dashboard data:", error);
            if (this.notification) {
                this.notification.add("Failed to load dashboard data. Please check your permissions.", {
                    type: "danger",
                });
            }
        } finally {
            this.state.isLoading = false;
            // Schedule chart re-rendering after DOM update
            setTimeout(() => this.renderCharts(), 50);
        }
    }

    async onFilterChange() {
        await this.loadDashboardData();
    }

    async refreshData() {
        await this.loadDashboardData();
    }

    renderCharts() {
        if (!window.Chart) {
            return;
        }

        // 1. Monthly Collections Trend (Bar / Line)
        if (this.monthlyChartRef.el && this.state.data.monthly_trend) {
            if (this.monthlyChart) {
                this.monthlyChart.destroy();
            }

            const ctx = this.monthlyChartRef.el.getContext("2d");
            const labels = this.state.data.monthly_trend.map((item) => item.month);
            const values = this.state.data.monthly_trend.map((item) => item.amount);

            this.monthlyChart = new window.Chart(ctx, {
                type: "bar",
                data: {
                    labels: labels,
                    datasets: [
                        {
                            label: `Collections (${this.state.data.currency_symbol || ""})`,
                            data: values,
                            backgroundColor: "rgba(37, 99, 235, 0.75)",
                            borderColor: "#2563eb",
                            borderWidth: 1,
                            borderRadius: 6,
                        },
                    ],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            callbacks: {
                                label: (context) => `Collected: ${context.parsed.y.toLocaleString()}`,
                            },
                        },
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: "#f1f5f9" },
                        },
                        x: {
                            grid: { display: false },
                        },
                    },
                },
            });
        }

        // 2. Aging Distribution (Doughnut)
        if (this.agingChartRef.el && this.state.data.aging_distribution) {
            if (this.agingChart) {
                this.agingChart.destroy();
            }

            const ctx = this.agingChartRef.el.getContext("2d");
            const labels = this.state.data.aging_distribution.labels;
            const values = this.state.data.aging_distribution.values;

            this.agingChart = new window.Chart(ctx, {
                type: "doughnut",
                data: {
                    labels: labels,
                    datasets: [
                        {
                            data: values,
                            backgroundColor: [
                                "#10b981", // Not due - emerald
                                "#f59e0b", // 1-30 - amber
                                "#f97316", // 31-60 - orange
                                "#ef4444", // 61-90 - red
                                "#7c3aed", // 90+ - purple
                            ],
                            borderWidth: 2,
                            borderColor: "#ffffff",
                        },
                    ],
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: "bottom",
                            labels: {
                                boxWidth: 12,
                                padding: 12,
                                font: { size: 11 },
                            },
                        },
                        tooltip: {
                            callbacks: {
                                label: (context) => {
                                    const val = context.parsed;
                                    return ` ${context.label}: ${val.toLocaleString()}`;
                                },
                            },
                        },
                    },
                    cutout: "65%",
                },
            });
        }
    }

    // Drill-down Action Handlers
    async openAction(type) {
        const companyId = this.state.selectedCompanyId ? parseInt(this.state.selectedCompanyId) : null;
        const branchId = this.state.selectedBranchId ? parseInt(this.state.selectedBranchId) : null;

        let act = null;
        if (type === "outstanding") {
            act = await this.orm.call("ar.dashboard", "action_view_outstanding_receivables", [], {
                company_id: companyId,
                branch_id: branchId,
            });
        } else if (type === "overdue") {
            act = await this.orm.call("ar.dashboard", "action_view_overdue_receivables", [], {
                company_id: companyId,
                branch_id: branchId,
            });
        } else if (type === "collections") {
            act = await this.orm.call("ar.dashboard", "action_view_collections", [], {
                company_id: companyId,
                branch_id: branchId,
                date_from: this.state.dateFrom,
                date_to: this.state.dateTo,
            });
        } else if (type === "followups") {
            act = await this.orm.call("ar.dashboard", "action_view_followups", [], {
                company_id: companyId,
                branch_id: branchId,
                filter_type: "all",
            });
        }

        if (act) {
            this.action.doAction(act);
        }
    }

    openPartner(partnerId) {
        if (!partnerId) return;
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "res.partner",
            res_id: partnerId,
            views: [[false, "form"]],
            target: "current",
        });
    }

    openFollowup(followupId) {
        if (!followupId) return;
        this.action.doAction({
            type: "ir.actions.act_window",
            res_model: "ar.followup",
            res_id: followupId,
            views: [[false, "form"]],
            target: "current",
        });
    }

    openCustomers() {
        this.action.doAction("ar_management_dashboard.action_ar_customers");
    }

    openAgingWizard() {
        this.action.doAction("ar_management_dashboard.action_ar_aging_wizard");
    }
}

registry.category("actions").add("ar_management_dashboard.dashboard", ArDashboard);
