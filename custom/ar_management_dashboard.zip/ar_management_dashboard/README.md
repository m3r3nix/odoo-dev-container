# Accounts Receivable (AR) Management Dashboard for Odoo 19 Community Edition

A complete, enterprise-grade Accounts Receivable Management, Branch Security, Aging Analysis, and Collection Follow-up suite built specifically for **Odoo 19 Community Edition**.

---

## 1. Features Overview

* **Real-Time Interactive AR Dashboard (OWL 2)**:
  * 6 Core KPI cards: Total Outstanding, Overdue Receivables, Not Yet Due, Overdue > 90 Days, Period Collections, and Collection Efficiency Rate.
  * Customer metrics: Total Customers with Open Balances, Total Overdue Accounts.
  * Monthly collection trend bar chart (historical 6 months).
  * Aging distribution doughnut chart (5 standard aging buckets).
  * Top Debtors and Most Overdue Customer summary tables with direct partner navigation.
  * Recent collections ledger and pending follow-ups with one-click drilldown.
  * Multi-company and multi-branch filters with instant client-side reactivity.
* **Explicit Multi-Branch Management (`ar.branch`)**:
  * Dedicated branch model with unique code per company, assigned branch managers, and authorized users.
  * Association of accounting transactions (`account.move`, `account.payment`, `account.move.line`) and customers (`res.partner`) with branches.
  * Strict record-level security rules preventing cross-branch data leaks for Branch Managers.
* **Accurate Accounting Calculations**:
  * Built directly on Odoo's posted journal entries and move lines (`account.move.line` with `asset_receivable` account type).
  * True reconciliation and residual calculation avoiding double-counting of payments or unallocated credit notes.
  * Robust multi-currency handling utilizing Odoo currency rates and rounding.
  * Historical as-of-date aging using reconciliation timestamping (`account.partial.reconcile`).
* **Collection Follow-ups Workflow (`ar.followup`)**:
  * Manage collection activities with Priorities (Low, Normal, High, Urgent) and Statuses (Planned, In Progress, Contacted, Promise to Pay, Resolved, Cancelled).
  * Track contact methods (Phone, Email, In-Person Visit, WhatsApp/SMS, Formal Letter).
  * Enforce promised payment amounts and target dates.
  * Calendar, Kanban, and List views with overdue alerts.
* **Professional QWeb & Excel (XLSX) Reports**:
  * AR Aging Analysis Report (PDF & XLSX) with customer subtotals and 5 aging buckets.
  * Customer Account Statement (PDF & XLSX) with opening balance, running activity, and closing balance.
  * Outstanding Invoices, Overdue Invoices, and Collections Summary PDF reports.

---

## 2. Technical Requirements & Prerequisites

* **Odoo Version**: Odoo 19.0 Community Edition
* **Python Runtime**: Python 3.10+
* **Database**: PostgreSQL 14+
* **Odoo Base Dependencies**:
  * `base`
  * `account`
  * `web`
* **Python External Dependencies**:
  * `xlsxwriter` (for Excel report generation)

### Installing Python Dependencies

To install required external libraries in your Odoo Python environment:

```bash
pip install xlsxwriter
```

---

## 3. Module Placement & Addons Path

1. Copy or clone the `ar_management_dashboard` folder into your custom addons directory:

```bash
# Example structure
/opt/odoo/custom-addons/ar_management_dashboard
```

2. Ensure your custom addons directory is added to your Odoo configuration file (`odoo.conf`):

```ini
[options]
addons_path = /opt/odoo/odoo/addons,/opt/odoo/custom-addons
```

---

## 4. Installation & Upgrade Instructions

### Installing the Module (Web UI)

1. Activate **Developer Mode** in Odoo (`Settings` > `Developer Tools` > `Activate the developer mode`).
2. Navigate to **Apps** > Click **Update Apps List**.
3. Search for `Accounts Receivable (AR) Management Dashboard` or `ar_management_dashboard`.
4. Click **Install**.

### Installing via Command Line (CLI)

```bash
odoo-bin -c /path/to/odoo.conf -d your_database_name -i ar_management_dashboard --stop-after-init
```

### Upgrading the Module

When updating module code or views, run:

```bash
odoo-bin -c /path/to/odoo.conf -d your_database_name -u ar_management_dashboard --stop-after-init
```

---

## 5. Security & User Role Configuration

The module implements two distinct security roles under the **Accounts Receivable** category:

| Role | Group Technical ID | Capabilities |
| :--- | :--- | :--- |
| **AR Branch Manager** | `ar_management_dashboard.group_ar_branch_manager` | Can view, create, and manage AR records, invoices, payments, follow-ups, and reports **only within their assigned branches**. |
| **AR Administrator** | `ar_management_dashboard.group_ar_admin` | Full company-wide access across all branches, branch configuration, dashboard, and global financial reports. |

### Assigning Roles & Branches to Users

1. Navigate to **Settings** > **Users & Companies** > **Users**.
2. Select the user:
   * Under **Accounts Receivable**, assign **AR Branch Manager** or **AR Administrator**.
   * If assigned as **AR Branch Manager**, open the **Authorized AR Branches** field and select the branches the manager is permitted to oversee.
3. Save the user record.

---

## 6. How to Use the System

### 1. Configure Branches

* Navigate to **AR Management** > **Configuration** > **Branches**.
* Click **New**, enter the **Branch Name** (e.g. *Central Regional Branch*), a unique **Branch Code** (e.g. *CRB-01*), and select the **Company**.
* Assign authorized branch managers and users.

### 2. Associate Transactions with Branches

* On Customer Invoices (`account.move`), the **Branch** field is automatically populated from the Customer's assigned branch or can be selected manually.
* On Customer Payments (`account.payment`), specify the branch receiving the payment.

### 3. Monitoring the AR Dashboard

* Navigate to **AR Management** > **Dashboard**.
* Use the top filter bar to filter by Company, Branch, or Date Range.
* Click on any KPI card (e.g. *Total Overdue* or *Total Receivables*) to drill down directly into the filtered list of invoices.
* Inspect the **Monthly Collections Trend** and **Aging Distribution** charts.
* Review **Top Debtors** and click on any partner to inspect their complete credit profile.

### 4. Logging Collection Follow-ups

* Navigate to **AR Management** > **Follow-ups** or click **Follow-ups** directly on the customer form.
* Log communications, set status (*Contacted*, *Promise to Pay*), and record promised amounts and payment dates.
* Overdue follow-ups are automatically highlighted in red on the dashboard and follow-up lists.

### 5. Generating Reports

* **Aging Analysis**:
  * Navigate to **AR Management** > **Reporting** > **Aging Analysis**.
  * Select the **As of Date**, optional **Branch**, and **Filter Type** (*All* or *Overdue Only*).
  * Click **Print PDF Report** for a formatted document or **Export Excel (XLSX)** for detailed spreadsheet analysis.
* **Customer Account Statement**:
  * Navigate to **AR Management** > **Reporting** > **Customer Statement** or click the **Statement** stat button on any customer form.
  * Select the **Date Range** and click **Print PDF Statement** or **Export Excel (XLSX)**.

---

## 7. Accounting Assumptions & Calculation Logic

1. **Receivable Balances**: Calculated strictly from posted `account.move.line` entries where `account_id.account_type == 'asset_receivable'`. Draft or cancelled moves are excluded.
2. **Double-Counting Prevention**: Balances are calculated using line residuals and actual reconciliation matches (`account.partial.reconcile`), not by simply subtracting total payments from total invoices.
3. **Historical Aging Calculation**: When running an aging report as of a historical date $T$:
   * Invoices posted after $T$ are excluded.
   * Partial reconciliations that occurred after $T$ are disregarded, accurately displaying the unpaid invoice balance as of that specific past date.
4. **Aging Buckets**:
   * **Not Due**: Due date $> \text{As-of Date}$
   * **1–30 Days Overdue**: $1 \le (\text{As-of Date} - \text{Due Date}) \le 30$
   * **31–60 Days Overdue**: $31 \le (\text{As-of Date} - \text{Due Date}) \le 60$
   * **61–90 Days Overdue**: $61 \le (\text{As-of Date} - \text{Due Date}) \le 90$
   * **90+ Days Overdue**: $(\text{As-of Date} - \text{Due Date}) > 90$
5. **Collection Rate Calculation**:
   $$\text{Collection Rate} = \frac{\text{Collections in Period}}{\text{Total Outstanding at End of Period} + \text{Collections in Period}} \times 100$$

---

## 8. Limitations & Scope

* The module is designed natively for **Odoo 19 Community Edition** and does not require or depend on the proprietary `account_accountant` or `account_reports` Enterprise modules.
* Dynamic multi-level grouping in the interactive web client is powered by the custom OWL dashboard and standard Odoo search filters; financial report drilldowns use standard Odoo list/form views.
* If `xlsxwriter` is not installed on the host system, PDF exports remain fully operational while Excel export buttons will display a clear notification directing the administrator to install `xlsxwriter`.

---

## 9. License

This module is licensed under the **LGPL-3** (GNU Lesser General Public License v3.0).
